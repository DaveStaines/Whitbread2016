package com.whitbread.foursquare.dao;

import com.whitbread.foursquare.model.Place;
import com.whitbread.foursquare.model.Venue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Tests the {@link FoursquareDAO} class.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class FoursquareDAOTest {

    @Test
    public void testGetPlace() {
        FoursquareDAO dao = new FoursquareDAO();
        Place place = dao.getPlace("there");
        assertNotNull(place);
    }

    @Test
    public void testGetVenuesWithin() {
        FoursquareDAO dao = new FoursquareDAO();
        Place place = new Place("there", BigDecimal.ZERO, BigDecimal.ZERO);
        List<Venue> venues = dao.getVenuesWithin(place, BigDecimal.valueOf(10000));

        assertNotNull(venues);
        assertFalse(venues.isEmpty());
        assertEquals(3, venues.size());
    }

}

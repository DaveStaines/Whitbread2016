package com.whitbread.foursquare.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.Matchers.equalTo;

/**
 * This class tests {@link FoursquareController} class.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class FoursquareControllerTest {

    @Autowired
    private MockMvc mvc;

    @Test
    public void testGetVenuesNearHere() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/nearby?name=here").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(equalTo("[{\"name\":\"at here\",\"popular\":true,\"latitude__1\":0,\"longitude__2\":0},{\"name\":\"south of here\",\"popular\":true,\"latitude__1\":-0.5,\"longitude__2\":0},{\"name\":\"west of here\",\"popular\":false,\"latitude__1\":0,\"longitude__2\":10.0}]")));
    }

}

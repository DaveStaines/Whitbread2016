package com.whitbread.foursquare.controller;

import com.whitbread.foursquare.model.UK;
import com.whitbread.foursquare.model.Place;
import com.whitbread.foursquare.model.Venue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller which allows you to search for a place by name and return the recommended or popular venues near that location.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
@RestController
public class FoursquareController {

    @Autowired
    private UK uk;

    /**
     * Returns nearby venues near the given location.
     *
     * @param placeName The name of the place/area that you are looking for venues in/nearby.
     * @return List of venues - empty if no nearby venues are found.
     */
    @RequestMapping("/nearby")
    public List<Venue> getNearbyVenues(@RequestParam(value="name") String placeName) {

        Place place = uk.getPlace(placeName);

        if (place == null) {
            return new ArrayList<>();
        }

        return uk.getNearbyVenues(place);
    }

}

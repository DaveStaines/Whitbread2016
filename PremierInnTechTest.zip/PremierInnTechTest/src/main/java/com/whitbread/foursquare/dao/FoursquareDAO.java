package com.whitbread.foursquare.dao;

import com.whitbread.foursquare.model.Place;
import com.whitbread.foursquare.model.Venue;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;

/**
 * Dummy DAO implementation that returns static data.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
public class FoursquareDAO {

    public Place getPlace(String placeName) {
        return new Place(placeName, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    public List<Venue> getVenuesWithin(Place place, BigDecimal defaultRadiusInMeters) {

        BigDecimal radiusInDegLat = defaultRadiusInMeters.divide(BigDecimal.valueOf(1000), MathContext.DECIMAL64);
        BigDecimal radiusInDegLong = defaultRadiusInMeters.divide(BigDecimal.valueOf(50), MathContext.DECIMAL64);

        List<Venue> venues = new ArrayList<>();
        venues.add(new Venue("at " + place.getName(), place.getLatitude__1(), place.getLongitude__2(), true));
        venues.add(new Venue("south of " + place.getName(), place.getLatitude__1().subtract(radiusInDegLat), place.getLongitude__2(), true));
        venues.add(new Venue("west of " + place.getName(), place.getLatitude__1(), place.getLongitude__2().add(radiusInDegLong), false));
        return venues;
    }
}

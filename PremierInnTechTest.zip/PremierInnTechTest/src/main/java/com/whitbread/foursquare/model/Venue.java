package com.whitbread.foursquare.model;

import java.math.BigDecimal;

/**
 * Very similar to Place at the moment but likely to diverge.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
public final class Venue {

    private String name;
    private BigDecimal longitude;
    private BigDecimal latitude;
    private boolean popular;

    public Venue(String placeName, BigDecimal latitude, BigDecimal longitude, boolean popular) {
        this.name = placeName;
        this.latitude = latitude;
        this.longitude = longitude;
        this.popular = popular;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getLatitude__1() {
        return latitude;
    }

    public BigDecimal getLongitude__2() {
        return longitude;
    }

    public boolean isPopular() {
        return popular;
    }
}

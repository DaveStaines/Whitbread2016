package com.whitbread.foursquare.model;

import com.whitbread.foursquare.dao.FoursquareDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.math.BigDecimal;
import java.util.List;

/**
 * Uses application properties and the dao to return appropriate places and venues.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
@Configuration
@PropertySource("classpath:application.properties")
public class UK {

    @Value("${prop.uk.venue.defaultRadiusInMeters}")
    private double defaultRadiusInMeters;

    @Autowired
    private FoursquareDAO foursquareDAO;

    public Place getPlace(String placeName) {
        return foursquareDAO.getPlace(placeName);
    }

    public List<Venue> getNearbyVenues(Place place) {
        return foursquareDAO.getVenuesWithin(place, BigDecimal.valueOf(defaultRadiusInMeters));
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

}

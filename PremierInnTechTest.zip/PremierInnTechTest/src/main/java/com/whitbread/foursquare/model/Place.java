package com.whitbread.foursquare.model;

import java.math.BigDecimal;

/**
 * Very similar to Venue at the moment but likely to diverge.
 *
 * User: dave_staines
 * Date: 19/10/2016
 */
public final class Place {

    private String name;
    private BigDecimal longitude;
    private BigDecimal latitude;

    public Place(String placeName, BigDecimal latitude, BigDecimal longitude) {
        this.name = placeName;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getLatitude__1() {
        return latitude;
    }

    public BigDecimal getLongitude__2() {
        return longitude;
    }


}

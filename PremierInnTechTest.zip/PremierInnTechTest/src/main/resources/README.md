Basic implementation of the product developer test using hard-coded data.

To run application, use "spring-boot:run" Maven command.

To test, use WebService:
http://localhost:8080/nearby?name=here
